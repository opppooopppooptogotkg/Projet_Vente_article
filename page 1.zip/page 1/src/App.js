import logo from './logo.svg';
import React, { useState } from 'react'; // Ajoutez useState ici
import imageConnexion from './assets/images/image_connexion.jpg'
import './App.css';

function App() {

  const [password, setPassword] = useState(''); // État pour stocker le mot de passe
  const [showPassword, setShowPassword] = useState(false); // État pour déterminer la visibilité du mot de passe

  // Fonction pour basculer l'affichage du mot de passe
  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword); // Inverse la valeur de showPassword
  };


  return (
    <div className="contenu">

      
      <div className="image">

      

      </div>

      <div className="formulaire">

        <form>
          <h1>Join Us</h1>
          <h3 id="yu" >Create an account</h3>
          <br />
          <label>Nom </label>
          <br />
          <input type="text" placeholder = "Entrer votre nom "/>
          <br/>
          <br/>
          <label>Email</label>
          <br/>
          <input type="email" placeholder="Entrer votre email"/>
          <br />
          <br/>
          <label>Mot de passe</label>
          <br/>
          <input type="password"  placeholder="Entrer votre mot de passe" />
          <br/>
          <br/>
          <input type = "submit" id="bouton" value = "Creer mon compte" required/>
          <br />
          <br/>
          
          <p>Avez-vous deja un compte ? <a href="#">Se Connecter</a></p>

          

        </form>

      </div>
      


    </div>
  );
}

export default App;
